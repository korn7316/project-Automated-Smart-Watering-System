import 'package:flutter/material.dart';

void showWeightDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: Text(
          'ไม่สามารถบันทึกได้',
          style: TextStyle(fontFamily: 'Kanit'),
        ),
        content: Text(
          'ไม่สามารถบันทึกค่านี้ได้เนื่องจากผลรวมเกิน 100 %\nกรุณาใส่ค่าใหม่ในการบันทึก',
          style: TextStyle(fontFamily: 'Kanit'),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text(
              'ตกลง',
              style: TextStyle(fontFamily: 'Kanit'),
            ),
          )
        ],
      );
    },
  );
}
