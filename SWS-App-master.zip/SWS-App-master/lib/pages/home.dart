import 'dart:ui';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';
import 'package:sws_app/pages/dialog.dart';
import 'package:sws_app/service/dataService.dart';
// import 'package:sws_app/util/animation.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver, TickerProviderStateMixin {
  double width, height;
  bool autoWater = false, setting = false, canEditRange = false, canEditWeightDist = false, canScroll = false, setTime = false, start = false;
  List<String> rangeTextList, timeAutoText, timeAutoValue;
  List<TextEditingController> _rangeController, _weightController;
  CrossFadeState _crossFadeState;
  ScrollController _controller = ScrollController();

  List<FocusNode> focusRange = [for (var i = 0; i < 5; i++) FocusNode()], focusWeight = [for (var i = 0; i < 3; i++) FocusNode()];

  String startTime = '00:00', endTime = '00:00';

  int temp, soil, cor;

  int point, timeEst;

  DatabaseReference _databaseRef = FirebaseDatabase.instance.reference().child('swsapp');

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    _rangeController = [
      TextEditingController(text: '2'),
      TextEditingController(text: '4'),
      TextEditingController(text: '6'),
      TextEditingController(text: '8'),
      TextEditingController(text: '10'),
    ];
    _weightController = [
      TextEditingController(text: '30'),
      TextEditingController(text: '50'),
      TextEditingController(text: '20'),
    ];
    rangeTextList = ['0 - 20', '20 - 40', '40 - 60', '60 - 80', '80 - 100'];
    timeAutoText = ['time1', 'time2'];
    timeAutoValue = ['00:00', '00:00'];
    _crossFadeState = CrossFadeState.showFirst;
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeMetrics() async {
    super.didChangeMetrics();
    final value = WidgetsBinding.instance.window.viewInsets.bottom;
    if (value == 0) {
      FocusScope.of(context).unfocus();
      setState(() {
        canScroll = false;
      });
    } else {
      setState(() {
        canScroll = true;
      });
      await Future.delayed(Duration(milliseconds: 50));
      setState(() {
        if (canEditWeightDist) {
          _controller.animateTo(_controller.position.maxScrollExtent, duration: Duration(milliseconds: 150), curve: Curves.easeInOut);
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          Container(
            // BG
            width: width,
            height: height,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xff76b536), Color(0xffa5ce7b)],
                begin: Alignment.topLeft,
                end: Alignment(1, -0.6),
              ),
            ),
            alignment: Alignment.topLeft,
            child: Image.asset('assets/Leaves.png'),
          ),
          _buildAppBar(),
          _buildMainWidget(),
          setting ? Container() : _buildSWSwidget()
        ],
      ),
    );
  }

  Widget _buildBottomBar() {
    return Positioned(
      bottom: 0,
      child: setWorkingTimeField(),
    );
  }

  Widget _buildAppBar() {
    return Positioned(
      top: MediaQuery.of(context).padding.top + 25,
      left: 25,
      child: AnimatedCrossFade(
        firstChild: Container(
          width: width - 42,
          height: 50,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 4,
                  ),
                  Text(
                    'Welcome to SWS',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w500, fontSize: 16),
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Text(
                    'What are you up to?',
                    style: TextStyle(color: Color(0xffe9f3ed), fontSize: 14),
                  )
                ],
              ),
              IconButton(
                icon: Image.asset(
                  'assets/setting.png',
                  width: 31,
                  height: 31,
                ),
                padding: EdgeInsets.zero,
                color: Colors.white,
                iconSize: 31,
                alignment: Alignment.topRight,
                onPressed: () {
                  setState(() {
                    // forwardAnimation();
                    _crossFadeState = CrossFadeState.showSecond;
                    setting = true;
                  });
                },
              )
            ],
          ),
        ),
        secondChild: Container(
          width: width - 42,
          height: 50,
          alignment: Alignment.topCenter,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              IconButton(
                icon: Icon(Icons.arrow_back_ios),
                padding: EdgeInsets.zero,
                color: Colors.white,
                alignment: Alignment.topLeft,
                onPressed: () {
                  // Navigator.pop(context);
                  setState(() {
                    _crossFadeState = CrossFadeState.showFirst;
                    // reverseAnimation();
                    setting = false;
                  });
                },
              ),
              Spacer(),
              Text(
                'Setting',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.w500, fontSize: 16, height: 1.5),
              ),
              Spacer(),
              IconButton(
                icon: Icon(Icons.arrow_back_ios),
                color: Colors.transparent,
                onPressed: () {},
              ),
              SizedBox(width: 8)
            ],
          ),
        ),
        crossFadeState: _crossFadeState,
        firstCurve: Curves.ease,
        secondCurve: Curves.linear,
        duration: Duration(milliseconds: 200),
      ),
    );
  }

  Widget _buildSWSwidget() {
    return Positioned(
      left: width * 0.125,
      top: height * 0.21 - width * 0.07,
      child: StreamBuilder<Event>(
        stream: _databaseRef.onValue,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            var value = snapshot.data.snapshot.value;
            point = value['point'];
            List range = value['range'];
            if (point <= 20) {
              timeEst = range[0];
            } else if (point <= 40) {
              timeEst = range[1];
            } else if (point <= 60) {
              timeEst = range[2];
            } else if (point <= 80) {
              timeEst = range[3];
            } else {
              timeEst = range[4];
            }
          }

          return !snapshot.hasData
              ? Container(
                  width: width * 0.75,
                  height: width * 0.14,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey[300],
                        blurRadius: 10,
                        offset: Offset(0, 4),
                      )
                    ],
                    borderRadius: BorderRadius.circular(22),
                  ),
                )
              : Container(
                  width: width * 0.75,
                  height: width * 0.14,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey[300],
                        blurRadius: 10,
                        offset: Offset(0, 4),
                      )
                    ],
                    borderRadius: BorderRadius.circular(22),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                          width: width * 0.35,
                          height: width * 0.12,
                          alignment: Alignment.center,
                          child: RichText(
                            textAlign: TextAlign.center,
                            textScaleFactor: 1.1,
                            text: TextSpan(children: [
                              TextSpan(
                                text: 'Total Point\n',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 13,
                                  height: 1.3,
                                ),
                              ),
                              TextSpan(
                                text: point.toString(),
                                style: TextStyle(
                                  color: Color(0xff416D50),
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                  height: 1.3,
                                ),
                              )
                            ]),
                          )),
                      Container(
                        width: 1,
                        height: width * 0.1,
                        color: Color(0xffE9F3ED),
                      ),
                      Container(
                          width: width * 0.35,
                          height: width * 0.12,
                          alignment: Alignment.center,
                          child: RichText(
                            textAlign: TextAlign.center,
                            textScaleFactor: 1.1,
                            text: TextSpan(children: [
                              TextSpan(
                                text: 'Estimated Time\n',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 13,
                                  height: 1.3,
                                ),
                              ),
                              TextSpan(
                                text: '$timeEst min',
                                style: TextStyle(
                                  color: Color(0xff416D50),
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                  height: 1.3,
                                ),
                              )
                            ]),
                          )),
                    ],
                  ),
                );
        },
      ),
    );
  }

  bool startAnimation = true;
  Widget _buildMainWidget() {
    return AnimatedPositioned(
      curve: Cubic(0.68, -0.4, 0.265, 1.4),
      duration: Duration(milliseconds: 300),
      bottom: setting ? -10 : (height * -0.07) - 10,
      child: StreamBuilder<Event>(
          stream: _databaseRef.onValue,
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              dynamic value = snapshot.data.snapshot.value;
              // bool prevValue = setTime;
              setTime = value['timer']['active'];

              startTime = value['timer']['startTime'];
              endTime = value['timer']['endTime'];
              start = value['watering'];

              autoWater = value['autoWatering']['active'];

              timeAutoValue = [
                value['autoWatering']['time1'],
                value['autoWatering']['time2'],
              ];

              if (!canEditWeightDist) {
                _weightController = [
                  TextEditingController(text: (value['weightDist']['weatherCondition'] * 100.0).toStringAsFixed(0)),
                  TextEditingController(text: (value['weightDist']['temperature'] * 100.0).toStringAsFixed(0)),
                  TextEditingController(text: (value['weightDist']['soilMoisture'] * 100.0).toStringAsFixed(0)),
                ];
              }
              if (!canEditRange) {
                _rangeController = [
                  TextEditingController(text: value['range'][0].toString()),
                  TextEditingController(text: value['range'][1].toString()),
                  TextEditingController(text: value['range'][2].toString()),
                  TextEditingController(text: value['range'][3].toString()),
                  TextEditingController(text: value['range'][4].toString())
                ];
              }
              temp = value['monitorData']['temperature'];
              soil = value['monitorData']['soilMoisture'];
              cor = value['monitorData']['chanceOfRain'];
            }
            return !snapshot.hasData
                ? Container(
                    width: width,
                    height: height * 0.86 + 10,
                    decoration: BoxDecoration(
                      color: setting ? Color(0xFFFAFDFA) : Colors.white,
                      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                    ),
                    alignment: Alignment.center,
                    child: Text('please wait *-*'),
                  )
                : GestureDetector(
                    onTap: () {
                      FocusScope.of(context).unfocus();
                    },
                    child: Container(
                      width: width,
                      height: height * 0.86 + 10,
                      decoration: BoxDecoration(
                        color: setting ? Color(0xFFFAFDFA) : Colors.white,
                        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                      ),
                      padding: setting ? EdgeInsets.only(top: 25) : EdgeInsets.only(left: 25, right: 25, top: width * 0.075 + 15, bottom: 10 + (height * 0.07)),
                      //main
                      child: setting
                          ? _buildSettingWidget()
                          : Stack(
                              children: [
                                _buildHomeWidget(),
                                _buildBottomBar(),
                              ],
                            ),
                    ),
                  );
          }),
    );
  }

  Widget _buildHomeWidget() {
    return ListView(
      physics: BouncingScrollPhysics(),
      padding: EdgeInsets.only(top: 0, bottom: 105),
      children: [
        dataField(),
        SizedBox(height: 20),
        chanceOfRainField(),
        SizedBox(height: 20),
        controlField(),
      ],
    );
  }

  Widget dataField() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(
          width: width * 0.4,
          height: width * 0.325,
          decoration: BoxDecoration(
            color: Color(0xffe9f3ed),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Text(
                'Temperature',
                style: TextStyle(color: Color(0xff819382), fontSize: 16),
              ),
              Text(
                '$temp °C',
                style: TextStyle(color: Color(0xff416D50), fontSize: 36, fontWeight: FontWeight.w500),
              ),
              good()
            ],
          ),
        ),
        Container(
          width: width * 0.4,
          height: width * 0.325,
          decoration: BoxDecoration(
            color: Color(0xffe9f3ed),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Text(
                'Soil Moisture',
                style: TextStyle(color: Color(0xff819382), fontSize: 16),
              ),
              Text(
                '$soil %',
                style: TextStyle(color: Color(0xff416D50), fontSize: 36, fontWeight: FontWeight.w500),
              ),
              normal()
            ],
          ),
        )
      ],
    );
  }

  Widget good() {
    return Container(
      width: width * 0.18,
      height: width * 0.052,
      decoration: BoxDecoration(color: Color(0xff76B536), borderRadius: BorderRadius.circular(20)),
      alignment: Alignment.center,
      child: Text(
        'Good',
        style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w500),
      ),
    );
  }

  Widget normal() {
    return Container(
      width: width * 0.18,
      height: width * 0.052,
      decoration: BoxDecoration(color: Color(0xffFFBA00), borderRadius: BorderRadius.circular(20)),
      alignment: Alignment.center,
      child: Text(
        'Normal',
        style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w500),
      ),
    );
  }

  Widget bad() {
    return Container(
      width: width * 0.18,
      height: width * 0.052,
      decoration: BoxDecoration(color: Color(0xffFF0f00), borderRadius: BorderRadius.circular(20)),
      alignment: Alignment.center,
      child: Text(
        'Bad',
        style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w500),
      ),
    );
  }

  Widget chanceOfRainField() {
    return Container(
      width: width,
      height: 143,
      decoration: BoxDecoration(
        color: Color(0xffe9f3ed),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.horizontal(left: Radius.circular(20)),
            child: Image.asset(
              'assets/cloud.png',
              fit: BoxFit.fitHeight,
            ),
          ),
          Spacer(),
          RichText(
            textAlign: TextAlign.right,
            text: TextSpan(children: [
              TextSpan(
                text: 'Chance of Rain\n\n',
                style: TextStyle(color: Color(0xff819382), fontSize: 16),
              ),
              TextSpan(
                text: '$cor %',
                style: TextStyle(color: Color(0xff416D50), fontSize: 36, fontWeight: FontWeight.w500),
              ),
            ]),
          ),
          SizedBox(
            width: 20,
          ),
        ],
      ),
    );
  }

  Widget controlField() {
    return Container(
      width: width * 0.35,
      height: width * 0.45,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Value Control',
            style: TextStyle(color: Color(0xff416D50), fontSize: 16, fontWeight: FontWeight.w500),
          ),
          Container(
            width: width * 0.3,
            height: width * 0.3,
            child: TextButton(
              style: ButtonStyle(overlayColor: MaterialStateProperty.all(Colors.transparent), padding: MaterialStateProperty.all(EdgeInsets.zero)),
              onPressed: () {
                if (start) {
                  AppService.stopWatering();
                } else {
                  AppService.startWatering();
                }
              },
              child: AnimatedCrossFade(
                firstChild: Image.asset(
                  'assets/PWButtonOn.png',
                  fit: BoxFit.fill,
                ),
                secondChild: Image.asset(
                  'assets/PWButtonOff.png',
                  fit: BoxFit.fill,
                ),
                duration: Duration(milliseconds: 200),
                crossFadeState: !start ? CrossFadeState.showFirst : CrossFadeState.showSecond,
              ),
            ),
          ),
          Text(
            start ? 'Watering' : 'Stop Watering',
            style: TextStyle(color: Color(0xffA1A1AA), fontSize: 14, fontWeight: FontWeight.w300),
          ),
        ],
      ),
    );
  }

  Widget setWorkingTimeField() {
    return Container(
      width: width - 50,
      height: 85,
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(color: Color(0xffC4E1CD)),
        ),
        color: Colors.white,
      ),
      child: Stack(
        children: [
          AnimatedPositioned(
            duration: Duration(milliseconds: 200),
            top: setTime ? 0 : 20,
            left: 0,
            child: Container(
              width: width - 50,
              height: 85,
              child: Column(
                children: [
                  SizedBox(height: 8),
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          AppService.activeWorkingTime();
                        },
                        child: Image.asset(
                          'assets/AlarmIcon.png',
                          color: Color(0xFF124E14),
                          width: 30,
                          height: 30,
                        ),
                      ),
                      SizedBox(width: 16),
                      GestureDetector(
                        onTap: () {
                          AppService.activeWorkingTime();
                        },
                        child: Text(
                          'Set Working Time',
                          style: TextStyle(color: Color(0xff124e14), fontSize: 16, fontWeight: FontWeight.w500),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 4),
                  AnimatedOpacity(
                    duration: Duration(milliseconds: 100),
                    opacity: setTime ? 1.0 : 0.0,
                    child: Row(
                      children: [
                        Text(
                          'From ',
                          style: TextStyle(color: Color(0xff819382), fontSize: 16, fontWeight: FontWeight.w300),
                        ),
                        GestureDetector(
                          onTap: () {
                            print('open date picker');
                            DatePicker.showTimePicker(
                              context,
                              showSecondsColumn: false,
                              onConfirm: (time) {
                                print('${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}');
                                AppService.setStartWorkingTime('${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}');
                              },
                            );
                          },
                          child: Text(
                            startTime,
                            style: TextStyle(color: Color(0xff124e14), fontSize: 16, fontWeight: FontWeight.w500),
                          ),
                        ),
                        Text(
                          ' to ',
                          style: TextStyle(color: Color(0xff819382), fontSize: 16, fontWeight: FontWeight.w300),
                        ),
                        GestureDetector(
                          onTap: () {
                            print('open date picker');
                            DatePicker.showTimePicker(
                              context,
                              showSecondsColumn: false,
                              onConfirm: (time) {
                                print('${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}');
                                AppService.setEndWorkingTime('${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}');
                              },
                            );
                          },
                          child: Text(
                            endTime,
                            style: TextStyle(color: Color(0xff124e14), fontSize: 16, fontWeight: FontWeight.w500),
                          ),
                        ),
                        Spacer(),
                        GestureDetector(
                          onTap: () {
                            AppService.unActiveWorkingTime();
                          },
                          child: Image.asset(
                            'assets/Delete.png',
                            width: 19,
                            height: 19,
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildSettingWidget() {
    return ListView(
      physics: BouncingScrollPhysics(),
      controller: _controller,
      // physics: canScroll ? AlwaysScrollableScrollPhysics() : NeverScrollableScrollPhysics(),
      padding: EdgeInsets.only(left: 25, right: 25, bottom: canScroll ? 230 : 35),
      children: [
        _buildAutoWatering(),
        SizedBox(height: 20),
        _buildRangeSetting(),
        SizedBox(height: 20),
        _buildWeightDist(),
      ],
    );
  }

  Widget _buildAutoWatering() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Auto Watering Setting',
              style: TextStyle(
                fontSize: 16,
                color: Color(0xff124e14),
                fontWeight: FontWeight.w700,
              ),
            ),
            Container(
              height: 50,
              child: Transform.scale(
                scale: 0.8,
                alignment: Alignment.centerRight,
                child: CupertinoSwitch(
                  value: autoWater,
                  onChanged: (value) {
                    AppService.setEnableAuto(value);
                  },
                ),
              ),
            )
          ],
        ),
        Container(
          width: width,
          height: 136,
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: [
            BoxShadow(
              color: Color(0x402EB53B),
              offset: Offset(0, 2),
              blurRadius: 15,
            )
          ]),
          padding: EdgeInsets.only(top: 10),
          child: Column(
            children: [
              Container(
                width: width,
                height: 42,
                padding: EdgeInsets.symmetric(horizontal: 15),
                decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Color(0xFFD2EFD4)))),
                child: Row(
                  children: [
                    Text(
                      'No.',
                      style: TextStyle(
                        fontSize: 16,
                        color: Color(0xff124e14),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Spacer(),
                    Text(
                      'Time',
                      style: TextStyle(
                        fontSize: 16,
                        color: Color(0xff124e14),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Text(
                      ' (hh:mm)',
                      style: TextStyle(
                        fontSize: 16,
                        color: Color(0xff124e14),
                        fontWeight: FontWeight.w300,
                      ),
                    ),
                  ],
                ),
              ),
              for (var i = 0; i < 2; i++)
                Container(
                  width: width,
                  height: 42,
                  padding: EdgeInsets.symmetric(horizontal: 15),
                  decoration: BoxDecoration(border: Border(bottom: i == 1 ? BorderSide.none : BorderSide(color: Color(0xFFD2EFD4)))),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        timeAutoText[i],
                        style: TextStyle(
                          fontSize: 16,
                          color: Color(0xFF8E8E8E),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(
                        width: 100,
                        height: 35,
                        child: TextButton(
                          onPressed: !autoWater
                              ? null
                              : () {
                                  DatePicker.showTimePicker(
                                    context,
                                    showSecondsColumn: false,
                                    onConfirm: (time) {
                                      if (i == 0) {
                                        AppService.setAutoTime1('${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}');
                                      } else {
                                        AppService.setAutoTime2('${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}');
                                      }
                                    },
                                  );
                                },
                          style: ButtonStyle(
                            padding: MaterialStateProperty.all(EdgeInsets.zero),
                            alignment: Alignment.centerRight,
                            overlayColor: MaterialStateProperty.all(Colors.transparent),
                          ),
                          child: Text(
                            timeAutoValue[i],
                            style: TextStyle(
                              fontSize: 16,
                              color: !autoWater ? Colors.grey[350] : Color(0xFF8E8E8E),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                )
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildRangeSetting() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Range Setting',
              style: TextStyle(
                fontSize: 16,
                color: Color(0xff124e14),
                fontWeight: FontWeight.w700,
              ),
            ),
            TextButton(
              style: ButtonStyle(
                padding: MaterialStateProperty.all(EdgeInsets.zero),
                overlayColor: MaterialStateProperty.all(Colors.transparent),
                alignment: Alignment.centerRight,
              ),
              onPressed: () {
                setState(() {
                  FocusScope.of(context).unfocus();
                  canEditRange = !canEditRange;
                  if (canEditRange) {
                    FocusScope.of(context).requestFocus(focusRange[0]);
                  } else {
                    AppService.editRange(_rangeController);
                  }
                });
              },
              child: Text(
                canEditRange ? 'Save' : 'Edit',
                style: TextStyle(color: Color(0xff2eb53b), decoration: TextDecoration.underline, fontSize: 16),
              ),
            ),
          ],
        ),
        Container(
          width: width,
          height: 272,
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: [
            BoxShadow(
              color: Color(0x402EB53B),
              offset: Offset(0, 2),
              blurRadius: 15,
            )
          ]),
          padding: EdgeInsets.only(top: 20),
          child: Column(
            children: [
              Container(
                width: width,
                height: 42,
                padding: EdgeInsets.symmetric(horizontal: 15),
                decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Color(0xFFD2EFD4)))),
                child: Row(
                  children: [
                    Text(
                      'Point',
                      style: TextStyle(
                        fontSize: 16,
                        color: Color(0xff124e14),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Spacer(),
                    Text(
                      'Range',
                      style: TextStyle(
                        fontSize: 16,
                        color: Color(0xff124e14),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Text(
                      ' (min)',
                      style: TextStyle(
                        fontSize: 16,
                        color: Color(0xff124e14),
                        fontWeight: FontWeight.w300,
                      ),
                    ),
                  ],
                ),
              ),
              for (var i = 0; i < 5; i++)
                Container(
                  width: width,
                  height: 42,
                  padding: EdgeInsets.symmetric(horizontal: 15),
                  decoration: BoxDecoration(border: Border(bottom: i == 4 ? BorderSide.none : BorderSide(color: Color(0xFFD2EFD4)))),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        rangeTextList[i],
                        style: TextStyle(
                          fontSize: 16,
                          color: Color(0xFF8E8E8E),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(
                        width: 100,
                        height: 35,
                        child: TextFormField(
                          scrollPhysics: NeverScrollableScrollPhysics(),
                          textDirection: TextDirection.rtl,
                          minLines: null,
                          maxLines: null,
                          focusNode: focusRange[i],
                          maxLength: 9,
                          decoration: InputDecoration(
                              filled: true,
                              fillColor: Colors.transparent,
                              counterText: "",
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.all(
                                  Radius.circular(10.0),
                                ),
                                borderSide: BorderSide(color: Colors.transparent),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.all(
                                  Radius.circular(10.0),
                                ),
                                borderSide: BorderSide(color: canEditRange ? Colors.green[700] : Colors.transparent),
                              ),
                              contentPadding: EdgeInsets.symmetric(horizontal: 5)),
                          controller: _rangeController[i],
                          expands: true,
                          textAlignVertical: TextAlignVertical.center,
                          readOnly: !canEditRange,
                          style: TextStyle(
                            fontSize: 16,
                            color: Color(0xFF8e8e8e),
                            fontWeight: FontWeight.w500,
                          ),
                          keyboardType: TextInputType.number,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                        ),
                      )
                    ],
                  ),
                )
            ],
          ),
        ),
      ],
    );
  }

  List<String> weightTexts = [
    'Weather Condition',
    'Temperature',
    'Soil Moisture',
  ];

  Widget _buildWeightDist() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Weight Distribution Setting',
              style: TextStyle(
                fontSize: 16,
                color: Color(0xff124e14),
                fontWeight: FontWeight.w700,
              ),
            ),
            TextButton(
              style: ButtonStyle(
                padding: MaterialStateProperty.all(EdgeInsets.zero),
                overlayColor: MaterialStateProperty.all(Colors.transparent),
                alignment: Alignment.centerRight,
              ),
              onPressed: () {
                setState(() {
                  FocusScope.of(context).unfocus();
                  canEditWeightDist = !canEditWeightDist;
                  if (canEditWeightDist) {
                    FocusScope.of(context).requestFocus(focusWeight[0]);
                  } else {
                    if ((int.parse(_weightController[0].text) + int.parse(_weightController[1].text) + int.parse(_weightController[2].text)) > 100) {
                      canEditWeightDist = true;
                      showWeightDialog(context);
                    } else {
                      AppService.editWeight(_weightController);
                    }
                  }
                });
              },
              child: Text(
                canEditWeightDist ? 'Save' : 'Edit',
                style: TextStyle(color: Color(0xff2eb53b), decoration: TextDecoration.underline, fontSize: 16),
              ),
            ),
          ],
        ),
        Container(
          width: width,
          height: 230,
          padding: EdgeInsets.symmetric(vertical: 1),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: [
            BoxShadow(
              color: Color(0x402EB53B),
              offset: Offset(0, 2),
              blurRadius: 15,
            )
          ]),
          child: Column(
            children: [
              for (var i = 0; i < 3; i++)
                Container(
                    width: width,
                    height: 76,
                    padding: EdgeInsets.symmetric(horizontal: 15),
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: i == 2 ? BorderSide.none : BorderSide(color: Color(0xFFD2EFD4)),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          weightTexts[i],
                          style: TextStyle(
                            fontSize: 16,
                            color: Color(0xff124e14),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Spacer(),
                        SizedBox(
                          width: 75,
                          height: 35,
                          child: TextFormField(
                            scrollPhysics: NeverScrollableScrollPhysics(),
                            textDirection: TextDirection.rtl,
                            minLines: null,
                            maxLines: null,
                            focusNode: focusWeight[i],
                            maxLength: 9,
                            decoration: InputDecoration(
                                filled: true,
                                fillColor: Colors.transparent,
                                suffixText: '%',
                                counterText: "",
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(10.0),
                                  ),
                                  borderSide: BorderSide(color: Colors.transparent),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(10.0),
                                  ),
                                  borderSide: BorderSide(color: canEditWeightDist ? Colors.green[700] : Colors.transparent),
                                ),
                                contentPadding: EdgeInsets.symmetric(horizontal: 5)),
                            controller: _weightController[i],
                            expands: true,
                            textAlignVertical: TextAlignVertical.center,
                            readOnly: !canEditWeightDist,
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF8e8e8e),
                            ),
                            keyboardType: TextInputType.number,
                            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                          ),
                        ),
                      ],
                    )),
            ],
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }
}
