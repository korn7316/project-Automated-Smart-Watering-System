import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/widgets.dart';

class AppService {
  AppService._();

  static DatabaseReference _databaseRef = FirebaseDatabase.instance.reference().child('swsapp');

  static startWatering() {
    _databaseRef.update({
      'watering': true,
    });
  }

  static stopWatering() {
    _databaseRef.update({
      'watering': false,
    });
  }

  static activeWorkingTime() {
    _databaseRef.child('timer').update({
      'active': true,
    });
  }

  static unActiveWorkingTime() {
    _databaseRef.child('timer').update({
      'active': false,
    });
  }

  static setStartWorkingTime(String time) {
    _databaseRef.child('timer').update({
      'startTime': time,
    });
  }

  static setEndWorkingTime(String time) {
    _databaseRef.child('timer').update({
      'endTime': time,
    });
  }

  static setAutoTime1(String time) {
    _databaseRef.child('autoWatering').update({
      'time1': time,
    });
  }

  static setAutoTime2(String time) {
    _databaseRef.child('autoWatering').update({
      'time2': time,
    });
  }

  static setEnableAuto(bool active) {
    _databaseRef.child('autoWatering').update({
      'active': active,
    });
  }

  static editRange(List<TextEditingController> texts) {
    _databaseRef.child('range').update({
      '0': int.parse(texts[0].text),
      '1': int.parse(texts[1].text),
      '2': int.parse(texts[2].text),
      '3': int.parse(texts[3].text),
      '4': int.parse(texts[4].text),
    });
  }

  static editWeight(List<TextEditingController> texts) {
    _databaseRef.child('weightDist').update({
      'weatherCondition': double.parse(texts[0].text) / 100,
      'temperature': double.parse(texts[1].text) / 100,
      'soilMoisture': double.parse(texts[2].text) / 100,
    });
  }
}
